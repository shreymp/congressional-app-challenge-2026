export type TabType = 'live-alert' | 'avoided-logs' | 'sms-shield' | 'family-key-settings';

export type LogFilterType = 'all' | 'scam' | 'verified';

export interface ForensicDetails {
  callId: string;
  clearedStatus: string;
  originCarrier: string;
  sipCode: string;
  stirShakenLevel: 'A' | 'B' | 'C';
  audioWaveformVariance: string;
  syntheticMatchPercent: number;
  acousticSignature: string;
  networkHops: number;
  callerLocation: string;
  matchedDatabase?: string;
  transcriptSnippet?: string;
  timestamp: string;
}

export interface CallLogItem {
  id: string;
  type: 'scam' | 'verified';
  categoryTag: string; // 'PHISHING' | 'IMPERSONATION' | 'FRAUD' | 'EXTORTION' | 'ROBOCALL'
  statusBadge: string; // 'Safe' | 'Defended'
  statusType: 'safe' | 'defended' | 'verified';
  timestamp: string;
  phoneNumber: string;
  callerLabel: string;
  carrierOrLocation: string;
  summaryReason: string;
  defenseAction: string; // 'Auto-disconnected via Live Shield' | 'Blocked before ringing' | 'Matched Known FCC Blacklist'
  defenseIcon: string;
  familyKey?: string;
  isWhitelisted?: boolean;
  forensics: ForensicDetails;
}

export interface SmsMessageItem {
  id: string;
  sender: string;
  timestamp: string;
  content: string;
  extractedUrl?: string;
  threatLevel: 'critical' | 'high' | 'caution' | 'safe';
  scamType: string;
  analysisSummary: string;
  domainAge?: string;
  status: 'quarantined' | 'reviewed' | 'whitelisted';
}

export interface FamilyMember {
  id: string;
  name: string;
  relationship: string;
  phoneNumber: string;
  activeKey: string;
  stirShakenLevel: string;
  avatarBg: string;
  lastVerified: string;
  verifiedCount: number;
  autoAllow: boolean;
}
