/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { TabType, LogFilterType, CallLogItem, SmsMessageItem, FamilyMember } from './types';
import { INITIAL_CALL_LOGS, INITIAL_SMS_MESSAGES, INITIAL_FAMILY_MEMBERS } from './data/mockData';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { LogsScreen } from './components/LogsScreen';
import { LiveAlertScreen } from './components/LiveAlertScreen';
import { SmsShieldScreen } from './components/SmsShieldScreen';
import { FamilyKeyScreen } from './components/FamilyKeyScreen';
import { ForensicModal } from './components/ForensicModal';
import { ReportModal } from './components/ReportModal';
import { ProfileModal } from './components/ProfileModal';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('avoided-logs');
  const [logs, setLogs] = useState<CallLogItem[]>(INITIAL_CALL_LOGS);
  const [filter, setFilter] = useState<LogFilterType>('all');
  const [smsMessages, setSmsMessages] = useState<SmsMessageItem[]>(INITIAL_SMS_MESSAGES);
  const [familyMembers, setFamilyMembers] = useState<FamilyMember[]>(INITIAL_FAMILY_MEMBERS);
  const [currentFamilyKey, setCurrentFamilyKey] = useState<string>('#ORCHID-772');
  const [isGuardActive, setIsGuardActive] = useState<boolean>(true);

  // Modals state
  const [forensicModalLog, setForensicModalLog] = useState<CallLogItem | null>(null);
  const [reportModalLog, setReportModalLog] = useState<CallLogItem | null>(null);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState<boolean>(false);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setIsRefreshing(false);
    }, 1000);
  };

  const handleViewForensic = (log: CallLogItem) => {
    setForensicModalLog(log);
  };

  const handleReport = (log: CallLogItem) => {
    setReportModalLog(log);
  };

  const handleAlwaysAllow = (log: CallLogItem) => {
    // Add to family members if not already there
    const exists = familyMembers.some((m) => m.phoneNumber === log.phoneNumber);
    if (!exists) {
      setFamilyMembers((prev) => [
        {
          id: `fam-${Date.now()}`,
          name: log.callerLabel,
          relationship: 'Trusted Contact',
          phoneNumber: log.phoneNumber,
          activeKey: currentFamilyKey,
          stirShakenLevel: 'STIR/SHAKEN Level A',
          avatarBg: 'bg-emerald-100 text-emerald-700',
          lastVerified: 'Just now',
          verifiedCount: 1,
          autoAllow: true
        },
        ...prev
      ]);
    }
  };

  const handleAddBlockedCall = (newLog: CallLogItem) => {
    setLogs((prev) => [newLog, ...prev]);
  };

  const handleDeleteSms = (id: string) => {
    setSmsMessages((prev) => prev.filter((m) => m.id !== id));
  };

  const handleReportSms = (msg: SmsMessageItem) => {
    // Flag as reviewed/reported
    setSmsMessages((prev) =>
      prev.map((m) => (m.id === msg.id ? { ...m, status: 'reviewed' } : m))
    );
  };

  const handleRotateKey = (newKey: string) => {
    setCurrentFamilyKey(newKey);
    // Propagate to all family members
    setFamilyMembers((prev) =>
      prev.map((m) => ({ ...m, activeKey: newKey }))
    );
  };

  const handleAddFamilyMember = (newMember: FamilyMember) => {
    setFamilyMembers((prev) => [newMember, ...prev]);
  };

  return (
    <div className="min-h-screen bg-[#fcf9f8] text-[#1c1b1b] font-sans selection:bg-[#ffdad6] selection:text-[#410003] antialiased">
      {/* Top Header */}
      <Header
        isGuardActive={isGuardActive}
        onToggleGuard={() => setIsGuardActive(!isGuardActive)}
        onOpenSettings={() => setIsProfileModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="relative w-full max-w-md mx-auto pt-18 pb-24 px-4 bg-[#fcf9f8] min-h-screen">
        {activeTab === 'avoided-logs' && (
          <LogsScreen
            logs={logs}
            filter={filter}
            onFilterChange={setFilter}
            onViewForensic={handleViewForensic}
            onReport={handleReport}
            onAlwaysAllow={handleAlwaysAllow}
            onRefresh={handleRefresh}
            isRefreshing={isRefreshing}
          />
        )}

        {activeTab === 'live-alert' && (
          <LiveAlertScreen
            onAddBlockedCall={handleAddBlockedCall}
            isGuardActive={isGuardActive}
          />
        )}

        {activeTab === 'sms-shield' && (
          <SmsShieldScreen
            messages={smsMessages}
            onDeleteMessage={handleDeleteSms}
            onReportMessage={handleReportSms}
          />
        )}

        {activeTab === 'family-key-settings' && (
          <FamilyKeyScreen
            familyMembers={familyMembers}
            currentKey={currentFamilyKey}
            onRotateKey={handleRotateKey}
            onAddMember={handleAddFamilyMember}
          />
        )}
      </main>

      {/* Bottom Navigation */}
      <BottomNav
        activeTab={activeTab}
        onChangeTab={setActiveTab}
        unreadCount={smsMessages.length}
      />

      {/* Forensic Log Modal */}
      <ForensicModal
        isOpen={!!forensicModalLog}
        onClose={() => setForensicModalLog(null)}
        forensics={forensicModalLog?.forensics || null}
        phoneNumber={forensicModalLog?.phoneNumber}
        callerLabel={forensicModalLog?.callerLabel}
      />

      {/* Report Modal */}
      <ReportModal
        isOpen={!!reportModalLog}
        onClose={() => setReportModalLog(null)}
        phoneNumber={reportModalLog?.phoneNumber || ''}
        callerLabel={reportModalLog?.callerLabel}
        onSubmitted={(_phone) => {
          setReportModalLog(null);
        }}
      />

      {/* Profile & Telephony Settings Modal */}
      <ProfileModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
        isGuardActive={isGuardActive}
        onToggleGuard={() => setIsGuardActive(!isGuardActive)}
      />
    </div>
  );
}
