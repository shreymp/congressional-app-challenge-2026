import React from 'react';
import { APP_ICON_URL } from '../data/mockData';

interface HeaderProps {
  isGuardActive: boolean;
  onToggleGuard: () => void;
  onOpenSettings: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  isGuardActive,
  onToggleGuard,
  onOpenSettings
}) => {
  return (
    <header className="fixed top-0 w-full z-40 bg-[#fcf9f8]/90 backdrop-blur-xl shadow-[0_1px_8px_rgba(0,0,0,0.04)] pt-safe border-b border-[#f0eded]">
      <div className="h-16 max-w-md mx-auto px-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <img
            alt="CallShield App Icon"
            className="h-8 w-8 object-contain"
            src={APP_ICON_URL}
            referrerPolicy="no-referrer"
            onError={(e) => {
              // Graceful fallback if image network fails
              const target = e.currentTarget;
              target.style.display = 'none';
              if (target.nextElementSibling) {
                (target.nextElementSibling as HTMLElement).style.display = 'flex';
              }
            }}
          />
          <div className="hidden h-8 w-8 rounded-lg bg-[#af101a] text-white items-center justify-center font-bold text-sm">
            CS
          </div>

          <div className="flex flex-col">
            <span className="text-[17px] font-bold text-[#1c1b1b] leading-tight tracking-tight">
              CallShield
            </span>
            <button
              onClick={onToggleGuard}
              className="text-[11px] font-bold text-[#5b403d] flex items-center gap-1.5 hover:opacity-80 transition-opacity text-left cursor-pointer"
              title="Click to toggle Live Guard state"
            >
              <span
                className={`inline-block w-1.5 h-1.5 rounded-full ${
                  isGuardActive ? 'bg-[#1b6d24] animate-pulse' : 'bg-[#ba1a1a]'
                }`}
              />
              <span className="tracking-wide">
                {isGuardActive ? 'LIVE GUARD ON' : 'GUARD PAUSED'}
              </span>
            </button>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {isGuardActive ? (
            <div className="hidden sm:flex items-center gap-1 bg-[#a0f399] text-[#217128] px-2 py-0.5 rounded-full text-[12px] font-bold tracking-tight">
              <span className="material-symbols-outlined text-[14px]">verified_user</span>
              <span>SECURE</span>
            </div>
          ) : (
            <div className="hidden sm:flex items-center gap-1 bg-[#ffdad6] text-[#93000a] px-2 py-0.5 rounded-full text-[12px] font-bold tracking-tight">
              <span className="material-symbols-outlined text-[14px]">warning</span>
              <span>PAUSED</span>
            </div>
          )}

          <button
            onClick={onOpenSettings}
            className="w-8 h-8 rounded-full bg-[#af101a] text-white flex items-center justify-center shrink-0 hover:bg-[#8f0912] active:scale-95 transition-all shadow-sm cursor-pointer"
            aria-label="User profile and security settings"
          >
            <span className="material-symbols-outlined text-[18px]">person</span>
          </button>
        </div>
      </div>
    </header>
  );
};
