import React, { useState } from 'react';
import { SmsMessageItem } from '../types';

interface SmsShieldScreenProps {
  messages: SmsMessageItem[];
  onDeleteMessage: (id: string) => void;
  onReportMessage: (msg: SmsMessageItem) => void;
}

export const SmsShieldScreen: React.FC<SmsShieldScreenProps> = ({
  messages,
  onDeleteMessage,
  onReportMessage
}) => {
  const [testUrl, setTestUrl] = useState('');
  const [scanResult, setScanResult] = useState<{
    url: string;
    verdict: 'malicious' | 'safe' | 'suspicious';
    domainAge: string;
    targetBrand: string;
    sslIssuer: string;
    hops: number;
  } | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [toast, setToast] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  const handleScanUrl = (e: React.FormEvent) => {
    e.preventDefault();
    if (!testUrl.trim()) return;

    setIsScanning(true);
    setScanResult(null);

    setTimeout(() => {
      setIsScanning(false);
      const isClean = testUrl.includes('google.com') || testUrl.includes('apple.com');
      setScanResult({
        url: testUrl,
        verdict: isClean ? 'safe' : 'malicious',
        domainAge: isClean ? '27 years active' : 'Registered 3 hours ago (Anonymous Registrar)',
        targetBrand: isClean ? 'Verified Enterprise' : 'USPS / Financial Institution Clone',
        sslIssuer: isClean ? 'Google Trust Services' : "Let's Encrypt (Automated Disposable)",
        hops: isClean ? 1 : 4
      });
    }, 1200);
  };

  return (
    <div className="flex flex-col w-full gap-4">
      {/* Toast Notification */}
      {toast && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 bg-[#1c1b1b] text-white px-4 py-2 rounded-xl text-sm font-semibold shadow-lg flex items-center gap-2">
          <span className="material-symbols-outlined text-[18px] text-[#a0f399]">check_circle</span>
          <span>{toast}</span>
        </div>
      )}

      {/* Screen Header */}
      <div className="flex items-center justify-between pt-1">
        <div className="flex items-center gap-1.5">
          <span className="material-symbols-outlined text-[#af101a] text-[26px]">
            mark_chat_unread
          </span>
          <h1 className="text-[26px] font-bold text-[#1c1b1b] tracking-tight">
            SMS Shield
          </h1>
        </div>

        <div className="flex items-center gap-1.5 bg-[#eae7e7] px-2.5 py-1 rounded-full text-[#5b403d] text-[13px] font-bold">
          <span className="material-symbols-outlined text-[15px] text-[#1b6d24]">check</span>
          <span>Smishing Filter ON</span>
        </div>
      </div>

      {/* Stats Summary Card */}
      <div className="bg-white rounded-xl p-4 shadow-xs border border-[#eae7e7] flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-[12px] font-bold uppercase tracking-wider text-[#af101a] flex items-center gap-1">
              <span className="inline-block w-2 h-2 rounded-full bg-[#af101a]" />
              Smishing Defense Ledger
            </span>
            <h2 className="text-[20px] font-bold text-[#1c1b1b] mt-0.5">
              64 Fraudulent Texts Quarantined
            </h2>
          </div>
          <div className="w-10 h-10 rounded-full bg-[#ffdad6] text-[#93000a] flex items-center justify-center">
            <span className="material-symbols-outlined text-[22px]">sms_failed</span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2 pt-1 border-t border-[#f0eded]">
          <div className="p-2.5 bg-[#f6f3f2] rounded-lg">
            <span className="text-[11px] text-[#5b403d] font-bold">Credential Exposure</span>
            <p className="text-[16px] font-bold text-[#1b6d24]">0 Compromised</p>
          </div>
          <div className="p-2.5 bg-[#f6f3f2] rounded-lg">
            <span className="text-[11px] text-[#5b403d] font-bold">Malicious Domains</span>
            <p className="text-[16px] font-bold text-[#af101a]">100% Intercepted</p>
          </div>
        </div>
      </div>

      {/* Interactive SMS Link Deep Scanner */}
      <div className="bg-white rounded-xl p-4 shadow-xs border border-[#eae7e7] flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <span className="text-[13px] font-bold uppercase tracking-wider text-[#5b403d] flex items-center gap-1.5">
            <span className="material-symbols-outlined text-[17px] text-[#af101a]">travel_explore</span>
            Inspect Suspicious SMS Link
          </span>
          <span className="text-[11px] text-[#5b403d]">Sandbox Verification</span>
        </div>

        <form onSubmit={handleScanUrl} className="flex gap-2">
          <input
            type="text"
            value={testUrl}
            onChange={(e) => setTestUrl(e.target.value)}
            placeholder="Paste URL (e.g. usps-track-package94.info)"
            className="flex-1 text-[13px] px-3 py-2 rounded-xl border border-[#e5e2e1] bg-[#f6f3f2] focus:bg-white focus:outline-none focus:border-[#af101a]"
          />
          <button
            type="submit"
            disabled={isScanning || !testUrl.trim()}
            className="px-3.5 py-2 rounded-xl bg-[#af101a] text-white font-bold text-[13px] flex items-center gap-1 hover:bg-[#8f0912] active:scale-[0.98] transition-all disabled:opacity-50 cursor-pointer"
          >
            {isScanning ? (
              <span className="material-symbols-outlined text-[16px] animate-spin">sync</span>
            ) : (
              <span className="material-symbols-outlined text-[16px]">search</span>
            )}
            <span>{isScanning ? 'Probing...' : 'Scan'}</span>
          </button>
        </form>

        {scanResult && (
          <div
            className={`p-3 rounded-xl border text-[13px] flex flex-col gap-1.5 animate-in fade-in duration-150 ${
              scanResult.verdict === 'safe'
                ? 'bg-[#a0f399]/20 border-[#a0f399] text-[#005312]'
                : 'bg-[#fff2f0] border-[#ffdad6] text-[#410003]'
            }`}
          >
            <div className="flex items-center justify-between font-bold">
              <span className="flex items-center gap-1">
                <span className="material-symbols-outlined text-[18px]">
                  {scanResult.verdict === 'safe' ? 'verified' : 'gpp_bad'}
                </span>
                <span>
                  {scanResult.verdict === 'safe'
                    ? 'Legitimate Domain Verified'
                    : 'CRITICAL PHISHING CAMPAIGN DETECTED'}
                </span>
              </span>
              <span className="text-[11px] uppercase px-2 py-0.5 rounded bg-white/70">
                {scanResult.verdict}
              </span>
            </div>
            <div className="grid grid-cols-2 gap-1 text-[12px] pt-1">
              <div>
                <span className="font-semibold">Domain Age:</span> {scanResult.domainAge}
              </div>
              <div>
                <span className="font-semibold">Impersonating:</span> {scanResult.targetBrand}
              </div>
              <div>
                <span className="font-semibold">Certificate:</span> {scanResult.sslIssuer}
              </div>
              <div>
                <span className="font-semibold">Redirect Hops:</span> {scanResult.hops} redirects
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Quarantined Messages Feed */}
      <div className="flex flex-col gap-2.5">
        <span className="text-[13px] font-bold uppercase tracking-wider text-[#5b403d] px-1">
          Quarantined Suspicious Messages
        </span>

        {messages.map((item) => (
          <div
            key={item.id}
            className="bg-white rounded-xl p-4 shadow-xs border border-[#eae7e7] flex flex-col gap-2.5"
          >
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="text-[15px] font-bold text-[#1c1b1b] font-mono">
                  {item.sender}
                </span>
                <span className="px-2 py-0.5 rounded-full bg-[#d32f2f] text-white text-[11px] font-bold uppercase">
                  {item.scamType}
                </span>
              </div>
              <span className="text-[12px] text-[#5b403d]">{item.timestamp}</span>
            </div>

            <div className="p-3 bg-[#f6f3f2] rounded-lg text-[13px] text-[#1c1b1b] leading-relaxed border-l-4 border-[#af101a]">
              "{item.content}"
            </div>

            {item.extractedUrl && (
              <div className="p-2 bg-[#ffdad6]/40 rounded-md text-[12px] text-[#410003] flex items-center justify-between">
                <span className="font-mono truncate max-w-[240px]">
                  {item.extractedUrl}
                </span>
                <span className="text-[11px] font-bold bg-[#ffdad6] px-1.5 py-0.5 rounded">
                  {item.domainAge}
                </span>
              </div>
            )}

            <p className="text-[12px] text-[#5b403d]">
              {item.analysisSummary}
            </p>

            <div className="flex items-center gap-2 pt-1">
              <button
                onClick={() => {
                  onReportMessage(item);
                  showToast('Smishing incident reported to Carrier Spam Registry (7726).');
                }}
                className="flex-1 py-2 rounded-lg bg-[#ffdad6] text-[#93000a] text-[13px] font-bold hover:bg-[#ffb3ac] flex items-center justify-center gap-1 cursor-pointer"
              >
                <span className="material-symbols-outlined text-[16px]">flag</span>
                <span>Report (7726)</span>
              </button>

              <button
                onClick={() => {
                  onDeleteMessage(item.id);
                  showToast('Quarantined message permanently purged.');
                }}
                className="py-2 px-3 rounded-lg bg-[#f0eded] text-[#5b403d] hover:text-[#1c1b1b] text-[13px] font-bold flex items-center justify-center gap-1 cursor-pointer"
              >
                <span className="material-symbols-outlined text-[16px]">delete</span>
                <span>Purge</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
