import React, { useState } from 'react';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  isGuardActive: boolean;
  onToggleGuard: () => void;
}

export const ProfileModal: React.FC<ProfileModalProps> = ({
  isOpen,
  onClose,
  isGuardActive,
  onToggleGuard
}) => {
  const [sensitivity, setSensitivity] = useState<'high' | 'medium' | 'strict'>('high');
  const [autoDropVoip, setAutoDropVoip] = useState(true);
  const [stirShakenOnly, setStirShakenOnly] = useState(false);
  const [syntheticVoiceAlerts, setSyntheticVoiceAlerts] = useState(true);

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 bg-[#313030]/60 backdrop-blur-sm flex flex-col justify-end sm:justify-center p-3 sm:p-4 transition-opacity animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-2xl p-4 shadow-2xl flex flex-col gap-4 max-w-md mx-auto w-full border border-[#eae7e7] max-h-[85vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-1 border-b border-[#f0eded]">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-[#af101a] text-white flex items-center justify-center font-bold text-sm">
              <span className="material-symbols-outlined text-[18px]">security</span>
            </div>
            <div>
              <h2 className="text-[17px] font-bold text-[#1c1b1b]">
                Protection Security Core
              </h2>
              <p className="text-[12px] text-[#5b403d]">Subscriber: azimchicago8@gmail.com</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[#f0eded] flex items-center justify-center text-[#5b403d] hover:text-[#1c1b1b] cursor-pointer"
          >
            <span className="material-symbols-outlined text-[18px]">close</span>
          </button>
        </div>

        {/* Master Guard Switch */}
        <div className="p-3 bg-[#f6f3f2] rounded-xl flex items-center justify-between border border-[#e5e2e1]">
          <div className="flex flex-col">
            <span className="text-[14px] font-bold text-[#1c1b1b]">
              Live Guard Shield
            </span>
            <span className="text-[12px] text-[#5b403d]">
              Continuous telemetry & zero-exposure call interception
            </span>
          </div>
          <button
            type="button"
            onClick={onToggleGuard}
            className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
              isGuardActive ? 'bg-[#1b6d24]' : 'bg-[#dcd9d9]'
            }`}
          >
            <div
              className={`w-5 h-5 rounded-full bg-white absolute top-0.5 transition-transform shadow-xs ${
                isGuardActive ? 'right-0.5' : 'left-0.5'
              }`}
            />
          </button>
        </div>

        {/* Sensitivity Profiles */}
        <div className="flex flex-col gap-2">
          <label className="text-[13px] font-bold text-[#1c1b1b]">
            Threat Mitigation Mode
          </label>
          <div className="grid grid-cols-3 gap-2">
            {[
              { id: 'medium', label: 'Balanced', desc: 'Warns on high risk' },
              { id: 'high', label: 'Proactive', desc: 'Auto-drop verified scams' },
              { id: 'strict', label: 'Strict VIP', desc: 'Keyed contacts only' }
            ].map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => setSensitivity(p.id as typeof sensitivity)}
                className={`p-2.5 rounded-xl text-left border flex flex-col gap-0.5 cursor-pointer transition-colors ${
                  sensitivity === p.id
                    ? 'border-[#af101a] bg-[#ffdad6] text-[#410003]'
                    : 'border-[#eae7e7] bg-white text-[#1c1b1b] hover:bg-[#f6f3f2]'
                }`}
              >
                <span className="text-[13px] font-bold">{p.label}</span>
                <span className="text-[10px] text-[#5b403d] leading-tight">{p.desc}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Telecommunication Protocol Controls */}
        <div className="flex flex-col gap-2.5">
          <label className="text-[13px] font-bold text-[#1c1b1b]">
            Telephony Protocol Enforcement
          </label>

          <label className="flex items-start gap-2.5 cursor-pointer">
            <input
              type="checkbox"
              checked={autoDropVoip}
              onChange={(e) => setAutoDropVoip(e.target.checked)}
              className="mt-1 accent-[#af101a]"
            />
            <div className="flex flex-col text-[12px]">
              <span className="font-semibold text-[#1c1b1b]">
                Auto-drop untrusted VoIP relays
              </span>
              <span className="text-[#5b403d]">
                Instantly disconnects calls routed through anonymous offshore SIP proxies.
              </span>
            </div>
          </label>

          <label className="flex items-start gap-2.5 cursor-pointer">
            <input
              type="checkbox"
              checked={stirShakenOnly}
              onChange={(e) => setStirShakenOnly(e.target.checked)}
              className="mt-1 accent-[#af101a]"
            />
            <div className="flex flex-col text-[12px]">
              <span className="font-semibold text-[#1c1b1b]">
                Require STIR/SHAKEN Attestation Level A
              </span>
              <span className="text-[#5b403d]">
                Blocks all callers without cryptographically verified carrier source certificates.
              </span>
            </div>
          </label>

          <label className="flex items-start gap-2.5 cursor-pointer">
            <input
              type="checkbox"
              checked={syntheticVoiceAlerts}
              onChange={(e) => setSyntheticVoiceAlerts(e.target.checked)}
              className="mt-1 accent-[#af101a]"
            />
            <div className="flex flex-col text-[12px]">
              <span className="font-semibold text-[#1c1b1b]">
                Deepfake & AI Voice Clone Interception
              </span>
              <span className="text-[#5b403d]">
                Samples first 200ms of incoming audio buffer to detect ElevenLabs / synthetic TTS models.
              </span>
            </div>
          </label>
        </div>

        <button
          onClick={onClose}
          className="w-full py-2.5 rounded-xl bg-[#af101a] text-white text-[14px] font-bold hover:bg-[#8f0912] active:scale-[0.99] transition-all cursor-pointer"
        >
          Save & Apply Configuration
        </button>
      </div>
    </div>
  );
};
