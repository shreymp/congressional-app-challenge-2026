import React, { useState } from 'react';
import { CallLogItem, LogFilterType } from '../types';

interface LogsScreenProps {
  logs: CallLogItem[];
  filter: LogFilterType;
  onFilterChange: (f: LogFilterType) => void;
  onViewForensic: (log: CallLogItem) => void;
  onReport: (log: CallLogItem) => void;
  onAlwaysAllow: (log: CallLogItem) => void;
  onRefresh: () => void;
  isRefreshing?: boolean;
}

export const LogsScreen: React.FC<LogsScreenProps> = ({
  logs,
  filter,
  onFilterChange,
  onViewForensic,
  onReport,
  onAlwaysAllow,
  onRefresh,
  isRefreshing = false
}) => {
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const filteredLogs = logs.filter((log) => {
    if (filter === 'all') return true;
    if (filter === 'scam') return log.type === 'scam';
    if (filter === 'verified') return log.type === 'verified';
    return true;
  });

  const totalScams = logs.filter((l) => l.type === 'scam').length;
  const totalVerified = logs.filter((l) => l.type === 'verified').length;
  const totalAll = logs.length;

  return (
    <div className="flex flex-col w-full gap-4">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 bg-[#1c1b1b] text-white px-4 py-2 rounded-xl text-sm font-semibold shadow-lg animate-in fade-in slide-in-from-top-2 duration-200 flex items-center gap-2">
          <span className="material-symbols-outlined text-[18px] text-[#a0f399]">check_circle</span>
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Protection Log Header & Tabs */}
      <div className="flex flex-col gap-2 pt-1">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <span className="material-symbols-outlined text-[#1b6d24] text-[26px]">
              verified
            </span>
            <h1 className="text-[26px] font-bold text-[#1c1b1b] tracking-tight">
              Protection Log
            </h1>
          </div>

          <button
            onClick={() => {
              onRefresh();
              showToast('Security registry synchronized with FCC STIR/SHAKEN database.');
            }}
            disabled={isRefreshing}
            className="flex items-center gap-1.5 bg-[#eae7e7] hover:bg-[#e5e2e1] active:scale-95 px-2.5 py-1 rounded-full text-[#5b403d] text-[13px] font-bold transition-all cursor-pointer"
            title="Refresh protection registry"
          >
            <span
              className={`material-symbols-outlined text-[15px] text-[#1b6d24] ${
                isRefreshing ? 'animate-spin' : ''
              }`}
            >
              sync
            </span>
            <span>Real-time</span>
          </button>
        </div>

        {/* Filter Tabs */}
        <div className="flex items-center gap-1 p-1 bg-[#f0eded] rounded-xl">
          <button
            className={`flex-1 py-1.5 px-2 rounded-lg text-center transition-all duration-200 text-[14px] font-bold cursor-pointer ${
              filter === 'all'
                ? 'bg-white text-[#1c1b1b] shadow-xs'
                : 'text-[#5b403d] hover:text-[#1c1b1b]'
            }`}
            onClick={() => onFilterChange('all')}
          >
            All ({totalAll > 6 ? 48 : totalAll})
          </button>
          <button
            className={`flex-1 py-1.5 px-2 rounded-lg text-center transition-all duration-200 text-[14px] font-bold cursor-pointer ${
              filter === 'scam'
                ? 'bg-white text-[#1c1b1b] shadow-xs'
                : 'text-[#5b403d] hover:text-[#1c1b1b]'
            }`}
            onClick={() => onFilterChange('scam')}
          >
            Scams ({totalScams > 4 ? 37 : totalScams})
          </button>
          <button
            className={`flex-1 py-1.5 px-2 rounded-lg text-center transition-all duration-200 text-[14px] font-bold cursor-pointer ${
              filter === 'verified'
                ? 'bg-white text-[#1c1b1b] shadow-xs'
                : 'text-[#5b403d] hover:text-[#1c1b1b]'
            }`}
            onClick={() => onFilterChange('verified')}
          >
            Verified ({totalVerified > 2 ? 11 : totalVerified})
          </button>
        </div>
      </div>

      {/* Summary Stats Banner */}
      <div className="bg-white rounded-xl p-4 shadow-xs flex flex-col gap-2 relative overflow-hidden border border-[#eae7e7]">
        {/* Decorative background watermark */}
        <div className="absolute -right-6 -bottom-6 opacity-5 pointer-events-none text-[#1b6d24]">
          <span className="material-symbols-outlined text-[130px]">shield</span>
        </div>

        <div className="flex items-start justify-between">
          <div className="flex flex-col">
            <span className="text-[12px] font-bold uppercase tracking-wider text-[#1b6d24] flex items-center gap-1.5">
              <span className="inline-block w-2 h-2 rounded-full bg-[#1b6d24]" />
              Monthly Shield Telemetry
            </span>
            <span className="text-[21px] text-[#1c1b1b] mt-0.5 font-bold leading-tight">
              37 Scam Calls Avoided this month
            </span>
          </div>

          <button
            onClick={() => showToast('Monthly telemetry report exported to secure storage.')}
            className="w-10 h-10 rounded-full bg-[#a0f399] flex items-center justify-center shrink-0 hover:bg-[#88d982] transition-colors cursor-pointer"
            aria-label="Export monthly report"
          >
            <span className="material-symbols-outlined text-[#217128] text-[22px]">
              markdown_copy
            </span>
          </button>
        </div>

        {/* Metric Pills Grid */}
        <div className="grid grid-cols-2 gap-2 pt-1">
          <div className="bg-[#f6f3f2] rounded-lg p-2.5 flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-[#1b6d24]/10 flex items-center justify-center shrink-0">
              <span className="material-symbols-outlined text-[#1b6d24] text-[18px]">
                timelapse
              </span>
            </div>
            <div className="flex flex-col min-w-0">
              <span className="text-[12px] text-[#5b403d] font-medium">Time Saved</span>
              <span className="text-[16px] font-bold text-[#1c1b1b] truncate">~4.2 hrs</span>
            </div>
          </div>

          <div className="bg-[#f6f3f2] rounded-lg p-2.5 flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-[#1b6d24]/10 flex items-center justify-center shrink-0">
              <span className="material-symbols-outlined text-[#1b6d24] text-[18px]">
                savings
              </span>
            </div>
            <div className="flex flex-col min-w-0">
              <span className="text-[12px] text-[#5b403d] font-medium">Financial Loss</span>
              <span className="text-[16px] text-[#1b6d24] truncate font-bold">$0 lost</span>
            </div>
          </div>
        </div>
      </div>

      {/* Incident Cards Section */}
      <div className="flex flex-col gap-3">
        {filteredLogs.length === 0 ? (
          <div className="bg-white rounded-xl p-8 text-center text-[#5b403d] border border-[#eae7e7]">
            <span className="material-symbols-outlined text-[36px] text-[#5b403d]/50">inbox</span>
            <p className="mt-2 font-medium">No records match this filter category.</p>
          </div>
        ) : (
          filteredLogs.map((log) => {
            if (log.type === 'verified') {
              return (
                <div
                  key={log.id}
                  className="bg-white rounded-xl p-4 shadow-xs flex flex-col gap-3 border border-[#eae7e7] transition-all hover:border-[#a0f399]"
                >
                  <div className="flex items-start justify-between gap-1">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="text-[16px] text-[#1b6d24] font-bold flex items-center gap-1">
                        <span className="material-symbols-outlined text-[20px]">check_circle</span>
                        Verified Caller - Family Key Active
                      </span>
                    </div>
                    <span className="text-[12px] text-[#5b403d] whitespace-nowrap pt-0.5">
                      {log.timestamp}
                    </span>
                  </div>

                  <div className="bg-[#f6f3f2] rounded-lg p-3 flex flex-col gap-1.5">
                    <div className="flex items-center justify-between text-[#1c1b1b]">
                      <div className="flex items-center gap-1.5">
                        <span className="material-symbols-outlined text-[18px] text-[#1b6d24]">
                          contact_phone
                        </span>
                        <span className="text-[15px] font-bold">{log.callerLabel}</span>
                      </div>
                      <span className="text-[14px] text-[#5b403d] font-mono">{log.phoneNumber}</span>
                    </div>

                    <div className="flex items-center justify-between pt-1">
                      <div className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-[#1b6d24] text-white text-[12px] font-bold">
                        <span className="material-symbols-outlined text-[14px]">key</span>
                        <span>Verified Key: {log.familyKey || '#ORCHID-772'}</span>
                      </div>
                      <span className="text-[12px] text-[#1b6d24] font-bold">
                        STIR/SHAKEN A-Level
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 pt-0.5">
                    <button
                      className="flex-1 py-2 px-3 rounded-lg bg-[#eae7e7] text-[#1c1b1b] hover:bg-[#e5e2e1] active:scale-[0.98] transition-all flex items-center justify-center gap-1.5 text-[14px] font-bold cursor-pointer"
                      onClick={() => onViewForensic(log)}
                    >
                      <span className="material-symbols-outlined text-[18px]">verified_user</span>
                      <span>View Verification Details</span>
                    </button>
                    <button
                      className="py-2 px-3 rounded-lg bg-[#e5e2e1] text-[#5b403d] hover:text-[#1c1b1b] hover:bg-[#dcd9d9] active:scale-[0.98] transition-all flex items-center justify-center gap-1 text-[14px] font-bold cursor-pointer"
                      onClick={() => {
                        onAlwaysAllow(log);
                        showToast(`${log.callerLabel} added to permanent whitelist.`);
                      }}
                    >
                      <span className="material-symbols-outlined text-[18px]">bookmark_added</span>
                      <span>Always Allow</span>
                    </button>
                  </div>
                </div>
              );
            }

            // Scam avoided card
            const isDefended = log.statusBadge === 'Defended';
            return (
              <div
                key={log.id}
                className="bg-white rounded-xl p-4 shadow-xs flex flex-col gap-3 border border-[#eae7e7] transition-all hover:border-[#ffdad6]"
              >
                <div className="flex items-start justify-between gap-1">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-[16px] text-[#1c1b1b] font-bold">
                      Scam call avoided
                    </span>
                    <span className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded-full bg-[#a0f399] text-[#217128] text-[12px] font-bold">
                      <span className="material-symbols-outlined text-[14px]">
                        {isDefended ? 'shield' : 'check_circle'}
                      </span>
                      {log.statusBadge}
                    </span>
                    <span className="inline-flex items-center px-2 py-0.5 rounded-full bg-[#d32f2f] text-white text-[11px] font-bold uppercase tracking-wide">
                      {log.categoryTag}
                    </span>
                  </div>
                  <span className="text-[12px] text-[#5b403d] whitespace-nowrap pt-0.5">
                    {log.timestamp}
                  </span>
                </div>

                <div className="bg-[#f6f3f2] rounded-lg p-3 flex flex-col gap-1">
                  <div className="flex items-center justify-between text-[#1c1b1b]">
                    <span className="text-[15px] font-bold tracking-tight font-mono">
                      {log.phoneNumber}
                    </span>
                    <span className="text-[13px] text-[#af101a] font-bold">
                      {log.carrierOrLocation}
                    </span>
                  </div>
                  <p className="text-[14px] text-[#5b403d]">
                    {log.summaryReason}
                  </p>
                  <div className="flex items-center gap-1 text-[#217128] text-[13px] font-semibold mt-0.5">
                    <span className="material-symbols-outlined text-[15px] text-[#1b6d24]">
                      {log.defenseIcon}
                    </span>
                    <span>{log.defenseAction}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2 pt-0.5">
                  <button
                    className="flex-1 py-2 px-3 rounded-lg bg-[#eae7e7] text-[#1c1b1b] hover:bg-[#e5e2e1] active:scale-[0.98] transition-all flex items-center justify-center gap-1.5 text-[14px] font-bold cursor-pointer"
                    onClick={() => onViewForensic(log)}
                  >
                    <span className="material-symbols-outlined text-[18px]">find_in_page</span>
                    <span>View Forensic Log</span>
                  </button>
                  <button
                    className="py-2 px-3 rounded-lg bg-[#ffdad6] text-[#93000a] hover:bg-[#ffb3ac] active:scale-[0.98] transition-all flex items-center justify-center gap-1 text-[14px] font-bold cursor-pointer"
                    onClick={() => onReport(log)}
                  >
                    <span className="material-symbols-outlined text-[18px]">flag</span>
                    <span>Report</span>
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Telephony & Compliance Legal Notice */}
      <div className="bg-[#f6f3f2] rounded-xl p-4 flex flex-col gap-1.5 shadow-xs border border-[#eae7e7]">
        <div className="flex items-center gap-1.5 text-[#5b403d]">
          <span className="material-symbols-outlined text-[18px] text-[#1b6d24]">
            encrypted
          </span>
          <span className="text-[12px] font-bold uppercase tracking-wider">
            Compliance & Privacy Standard
          </span>
        </div>
        <p className="text-[13px] text-[#5b403d] leading-relaxed">
          Recorded call snippets securely encrypted for customer protection. In compliance with FCC STIR/SHAKEN call authentication protocols and biometric telecommunication privacy rules.
        </p>
      </div>
    </div>
  );
};
