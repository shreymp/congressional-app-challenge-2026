import React, { useState } from 'react';
import { FamilyMember } from '../types';

interface FamilyKeyScreenProps {
  familyMembers: FamilyMember[];
  currentKey: string;
  onRotateKey: (newKey: string) => void;
  onAddMember: (member: FamilyMember) => void;
}

export const FamilyKeyScreen: React.FC<FamilyKeyScreenProps> = ({
  familyMembers,
  currentKey,
  onRotateKey,
  onAddMember
}) => {
  const [copiedKey, setCopiedKey] = useState(false);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newName, setNewName] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [newRelation, setNewRelation] = useState('Parent');
  const [duressWord, setDuressWord] = useState('BLUEBERRY-911');
  const [isEditingDuress, setIsEditingDuress] = useState(false);
  const [toast, setToast] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  const handleCopy = () => {
    navigator.clipboard?.writeText(currentKey);
    setCopiedKey(true);
    showToast(`Key ${currentKey} copied to clipboard.`);
    setTimeout(() => setCopiedKey(false), 2000);
  };

  const handleRotate = () => {
    const prefixes = ['FALCON', 'SEQUOIA', 'ORCHID', 'AURORA', 'COBALT', 'TITAN'];
    const randomPrefix = prefixes[Math.floor(Math.random() * prefixes.length)];
    const randomNum = Math.floor(100 + Math.random() * 900);
    const newKey = `#${randomPrefix}-${randomNum}`;
    onRotateKey(newKey);
    showToast(`Rotated to new Master Family Key: ${newKey}`);
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newPhone.trim()) return;

    onAddMember({
      id: `fam-${Date.now()}`,
      name: newName.trim(),
      relationship: newRelation,
      phoneNumber: newPhone.trim(),
      activeKey: currentKey,
      stirShakenLevel: 'STIR/SHAKEN Level A',
      avatarBg: 'bg-indigo-100 text-indigo-700',
      lastVerified: 'Just paired',
      verifiedCount: 0,
      autoAllow: true
    });

    setNewName('');
    setNewPhone('');
    setIsAddModalOpen(false);
    showToast(`${newName} paired with Family Key.`);
  };

  return (
    <div className="flex flex-col w-full gap-4">
      {/* Toast Notification */}
      {toast && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 bg-[#1c1b1b] text-white px-4 py-2 rounded-xl text-sm font-semibold shadow-lg flex items-center gap-2">
          <span className="material-symbols-outlined text-[18px] text-[#a0f399]">check_circle</span>
          <span>{toast}</span>
        </div>
      )}

      {/* Screen Header */}
      <div className="flex items-center justify-between pt-1">
        <div className="flex items-center gap-1.5">
          <span className="material-symbols-outlined text-[#1b6d24] text-[26px]">
            vpn_key
          </span>
          <h1 className="text-[26px] font-bold text-[#1c1b1b] tracking-tight">
            Family Key
          </h1>
        </div>

        <div className="flex items-center gap-1.5 bg-[#a0f399]/40 text-[#005312] px-2.5 py-1 rounded-full text-[13px] font-bold">
          <span className="material-symbols-outlined text-[15px] text-[#1b6d24]">lock</span>
          <span>Encrypted</span>
        </div>
      </div>

      {/* Master Key Card */}
      <div className="bg-white rounded-xl p-4 shadow-xs border border-[#eae7e7] flex flex-col gap-3">
        <div className="flex items-start justify-between">
          <div>
            <span className="text-[12px] font-bold uppercase tracking-wider text-[#1b6d24] flex items-center gap-1">
              <span className="inline-block w-2 h-2 rounded-full bg-[#1b6d24]" />
              Active Cryptographic Token
            </span>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-[24px] font-mono font-bold text-[#1b6d24] tracking-tight">
                {currentKey}
              </span>
              <button
                onClick={handleCopy}
                className="w-8 h-8 rounded-lg bg-[#f0eded] text-[#5b403d] hover:text-[#1c1b1b] flex items-center justify-center cursor-pointer"
                title="Copy Family Key"
              >
                <span className="material-symbols-outlined text-[18px]">
                  {copiedKey ? 'check' : 'content_copy'}
                </span>
              </button>
            </div>
          </div>

          <button
            onClick={handleRotate}
            className="px-3 py-1.5 rounded-xl bg-[#f0eded] hover:bg-[#e5e2e1] active:scale-95 text-[#1c1b1b] font-bold text-[13px] flex items-center gap-1 transition-all cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px] text-[#1b6d24]">autorenew</span>
            <span>Rotate Key</span>
          </button>
        </div>

        <div className="bg-[#f6f3f2] rounded-xl p-3 flex flex-col gap-1.5 border border-[#e5e2e1]">
          <div className="flex items-center gap-1.5 text-[#1b6d24] text-[13px] font-bold">
            <span className="material-symbols-outlined text-[17px]">shield</span>
            <span>Why Family Key Defeats AI Voice Clones:</span>
          </div>
          <p className="text-[12px] text-[#5b403d] leading-relaxed">
            Scammers use 3-second audio samples to clone children or parents. CallShield authenticates outgoing calls using an encrypted out-of-band certificate handshake. Deepfakes fail the challenge instantly.
          </p>
        </div>
      </div>

      {/* Duress Safe-Word Protection */}
      <div className="bg-white rounded-xl p-4 shadow-xs border border-[#eae7e7] flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-[#ffdad6] text-[#93000a] flex items-center justify-center">
              <span className="material-symbols-outlined text-[18px]">sos</span>
            </div>
            <div>
              <h3 className="text-[14px] font-bold text-[#1c1b1b]">
                Emergency Duress Safe-Word
              </h3>
              <p className="text-[12px] text-[#5b403d]">
                Spoken covertly if a family member is in danger
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsEditingDuress(!isEditingDuress)}
            className="text-[12px] font-bold text-[#af101a] hover:underline cursor-pointer"
          >
            {isEditingDuress ? 'Save' : 'Change'}
          </button>
        </div>

        {isEditingDuress ? (
          <div className="flex gap-2">
            <input
              type="text"
              value={duressWord}
              onChange={(e) => setDuressWord(e.target.value)}
              className="flex-1 text-[13px] font-mono px-3 py-1.5 rounded-lg border border-[#e5e2e1]"
            />
            <button
              onClick={() => {
                setIsEditingDuress(false);
                showToast('Duress safe-word updated.');
              }}
              className="px-3 py-1.5 rounded-lg bg-[#af101a] text-white text-[13px] font-bold cursor-pointer"
            >
              Done
            </button>
          </div>
        ) : (
          <div className="p-2.5 bg-[#fff2f0] rounded-lg border border-[#ffdad6] flex items-center justify-between">
            <span className="text-[13px] font-mono font-bold text-[#410003]">
              Safe-Word: "{duressWord}"
            </span>
            <span className="text-[11px] font-bold text-[#930010] bg-white px-2 py-0.5 rounded">
              Silent 911 Trigger
            </span>
          </div>
        )}
      </div>

      {/* Enrolled Family Members */}
      <div className="flex flex-col gap-2.5">
        <div className="flex items-center justify-between px-1">
          <span className="text-[13px] font-bold uppercase tracking-wider text-[#5b403d]">
            Enrolled Family Devices ({familyMembers.length})
          </span>
          <button
            onClick={() => setIsAddModalOpen(true)}
            className="text-[13px] font-bold text-[#1b6d24] flex items-center gap-1 hover:underline cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px]">add_circle</span>
            <span>Add Member</span>
          </button>
        </div>

        {familyMembers.map((member) => (
          <div
            key={member.id}
            className="bg-white rounded-xl p-3.5 shadow-xs border border-[#eae7e7] flex items-center justify-between"
          >
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-[14px] ${member.avatarBg}`}>
                {member.name.charAt(0)}
              </div>
              <div className="flex flex-col">
                <span className="text-[14px] font-bold text-[#1c1b1b]">
                  {member.name}
                </span>
                <span className="text-[12px] text-[#5b403d] font-mono">
                  {member.phoneNumber}
                </span>
                <span className="text-[11px] text-[#1b6d24] font-semibold flex items-center gap-1 mt-0.5">
                  <span className="material-symbols-outlined text-[12px]">verified</span>
                  <span>{member.stirShakenLevel} · {member.verifiedCount} protected calls</span>
                </span>
              </div>
            </div>

            <div className="flex items-center gap-1.5">
              <span className="text-[11px] font-mono font-bold px-2 py-0.5 rounded-full bg-[#a0f399] text-[#005312]">
                ACTIVE
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Add Member Modal */}
      {isAddModalOpen && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-[#313030]/60 backdrop-blur-sm flex flex-col justify-end sm:justify-center p-3 sm:p-4"
          onClick={() => setIsAddModalOpen(false)}
        >
          <div
            className="bg-white rounded-2xl p-4 shadow-2xl max-w-md mx-auto w-full border border-[#eae7e7] flex flex-col gap-3"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-1 border-b border-[#f0eded]">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#1b6d24] text-[24px]">
                  person_add
                </span>
                <h3 className="text-[16px] font-bold text-[#1c1b1b]">
                  Enroll New Family Member
                </h3>
              </div>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="w-8 h-8 rounded-full bg-[#f0eded] flex items-center justify-center text-[#5b403d] cursor-pointer"
              >
                <span className="material-symbols-outlined text-[18px]">close</span>
              </button>
            </div>

            <form onSubmit={handleAddSubmit} className="flex flex-col gap-3">
              <div className="flex flex-col gap-1">
                <label className="text-[12px] font-bold text-[#1c1b1b]">Full Name / Nickname</label>
                <input
                  type="text"
                  required
                  placeholder="E.g., Grandpa Charlie"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="text-[13px] px-3 py-2 rounded-lg border border-[#e5e2e1]"
                />
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-[12px] font-bold text-[#1c1b1b]">Mobile Phone Number</label>
                <input
                  type="tel"
                  required
                  placeholder="+1 (555) 000-0000"
                  value={newPhone}
                  onChange={(e) => setNewPhone(e.target.value)}
                  className="text-[13px] px-3 py-2 rounded-lg border border-[#e5e2e1]"
                />
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-[12px] font-bold text-[#1c1b1b]">Relationship</label>
                <select
                  value={newRelation}
                  onChange={(e) => setNewRelation(e.target.value)}
                  className="text-[13px] px-3 py-2 rounded-lg border border-[#e5e2e1] bg-white"
                >
                  <option>Parent</option>
                  <option>Child</option>
                  <option>Spouse / Partner</option>
                  <option>Grandparent</option>
                  <option>Doctor / Caregiver</option>
                </select>
              </div>

              <div className="p-2.5 bg-[#f6f3f2] rounded-lg text-[12px] text-[#5b403d]">
                Upon saving, this contact will automatically be paired with active Master Key: <span className="font-mono font-bold text-[#1b6d24]">{currentKey}</span>.
              </div>

              <div className="flex items-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="flex-1 py-2 rounded-xl bg-[#f0eded] text-[#5b403d] font-bold text-[13px] cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 rounded-xl bg-[#1b6d24] text-white font-bold text-[13px] hover:bg-[#165a1e] cursor-pointer"
                >
                  Save & Pair Key
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
