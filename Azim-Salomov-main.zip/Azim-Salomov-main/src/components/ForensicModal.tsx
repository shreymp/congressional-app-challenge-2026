import React, { useState } from 'react';
import { ForensicDetails } from '../types';

interface ForensicModalProps {
  isOpen: boolean;
  onClose: () => void;
  forensics: ForensicDetails | null;
  phoneNumber?: string;
  callerLabel?: string;
}

export const ForensicModal: React.FC<ForensicModalProps> = ({
  isOpen,
  onClose,
  forensics,
  phoneNumber,
  callerLabel
}) => {
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [copiedPcap, setCopiedPcap] = useState(false);

  if (!isOpen || !forensics) return null;

  const handleSimulateAudio = () => {
    setIsPlayingAudio(true);
    // Play synthetic frequency tone using Web Audio API safely
    try {
      const audioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(440, audioCtx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(120, audioCtx.currentTime + 0.6);
      gain.gain.setValueAtTime(0.08, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.8);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.8);
    } catch {
      // Audio context might be restricted before interaction
    }

    setTimeout(() => {
      setIsPlayingAudio(false);
    }, 1200);
  };

  const handleCopyTelemetry = () => {
    navigator.clipboard?.writeText(JSON.stringify(forensics, null, 2));
    setCopiedPcap(true);
    setTimeout(() => setCopiedPcap(false), 2000);
  };

  const isVerified = forensics.stirShakenLevel === 'A';

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 bg-[#313030]/60 backdrop-blur-sm flex flex-col justify-end sm:justify-center p-3 sm:p-4 transition-opacity animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-2xl p-4 shadow-2xl flex flex-col gap-3 max-w-md mx-auto w-full max-h-[85vh] overflow-y-auto border border-[#eae7e7]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-1 border-b border-[#f0eded]">
          <div className="flex items-center gap-2">
            <span className={`material-symbols-outlined text-[24px] ${isVerified ? 'text-[#1b6d24]' : 'text-[#af101a]'}`}>
              {isVerified ? 'verified_user' : 'terminal'}
            </span>
            <div>
              <h2 className="text-[17px] font-bold text-[#1c1b1b] leading-tight">
                {isVerified ? 'Cryptographic Verification Record' : 'Live Forensic Signature'}
              </h2>
              <p className="text-[12px] text-[#5b403d]">
                {phoneNumber} · {callerLabel}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[#f0eded] flex items-center justify-center text-[#5b403d] hover:text-[#1c1b1b] transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <span className="material-symbols-outlined text-[18px]">close</span>
          </button>
        </div>

        {/* Call ID Banner */}
        <div className="bg-[#f0eded] rounded-xl p-3 flex flex-col gap-2 font-mono text-[13px] leading-relaxed text-[#1c1b1b]">
          <div className="flex justify-between items-center font-bold">
            <span className={isVerified ? 'text-[#1b6d24]' : 'text-[#af101a]'}>
              CALL_ID: {forensics.callId}
            </span>
            <span
              className={`px-2 py-0.5 rounded text-[11px] font-bold tracking-tight ${
                isVerified
                  ? 'bg-[#a0f399] text-[#217128]'
                  : 'bg-[#ffdad6] text-[#93000a]'
              }`}
            >
              {forensics.clearedStatus}
            </span>
          </div>

          <p className="text-[#5b403d] font-sans text-[13px] leading-snug">
            {forensics.acousticSignature}
          </p>

          {/* Telemetry Trace List */}
          <div className="p-2.5 bg-[#e5e2e1] rounded-lg text-[12px] flex flex-col gap-1.5 font-mono">
            <span className="text-[#1c1b1b] font-bold font-sans flex items-center justify-between">
              <span>Telemetry Trace Matrix:</span>
              <span className="text-[11px] text-[#5b403d] font-normal">{forensics.timestamp}</span>
            </span>
            <div className="flex items-center gap-1.5 text-[#5b403d]">
              <span className="w-1.5 h-1.5 rounded-full bg-[#af101a]" />
              <span>{forensics.sipCode}</span>
            </div>
            <div className="flex items-center gap-1.5 text-[#5b403d]">
              <span className="w-1.5 h-1.5 rounded-full bg-[#af101a]" />
              <span>STIR/SHAKEN Attestation: Level {forensics.stirShakenLevel} ({isVerified ? 'Provider Signed Pass' : 'Unverified caller ID'})</span>
            </div>
            <div className="flex items-center gap-1.5 text-[#5b403d]">
              <span className="w-1.5 h-1.5 rounded-full bg-[#af101a]" />
              <span>Audio Waveform Variance: {forensics.audioWaveformVariance}</span>
            </div>
            <div className="flex items-center gap-1.5 text-[#5b403d]">
              <span className="w-1.5 h-1.5 rounded-full bg-[#af101a]" />
              <span>Carrier Route: {forensics.originCarrier}</span>
            </div>
            {forensics.matchedDatabase && (
              <div className="flex items-center gap-1.5 text-[#5b403d]">
                <span className="w-1.5 h-1.5 rounded-full bg-[#af101a]" />
                <span>Threat Registry: {forensics.matchedDatabase}</span>
              </div>
            )}
          </div>
        </div>

        {/* Transcript Snippet if available */}
        {forensics.transcriptSnippet && (
          <div className="p-3 bg-[#f6f3f2] rounded-xl flex flex-col gap-1 border border-[#e5e2e1]">
            <span className="text-[11px] uppercase tracking-wider font-bold text-[#5b403d] flex items-center gap-1">
              <span className="material-symbols-outlined text-[15px]">record_voice_over</span>
              Decrypted Audio Buffer Snippet
            </span>
            <p className="text-[13px] text-[#1c1b1b] italic font-sans">
              {forensics.transcriptSnippet}
            </p>
          </div>
        )}

        {/* Audio Spectrogram Simulator */}
        <div className="p-3 bg-[#f6f3f2] rounded-xl flex flex-col gap-2 border border-[#e5e2e1]">
          <div className="flex items-center justify-between">
            <span className="text-[12px] font-bold text-[#1c1b1b] flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[16px] text-[#1b6d24]">graphic_eq</span>
              Acoustic Biometric Verification
            </span>
            <span className={`text-[11px] font-bold ${isVerified ? 'text-[#1b6d24]' : 'text-[#af101a]'}`}>
              {isVerified ? '0.1% Synthetic' : `${forensics.syntheticMatchPercent}% Robotic Match`}
            </span>
          </div>

          {/* Dynamic Frequency Bars */}
          <div className="h-10 bg-[#1c1b1b] rounded-lg p-2 flex items-end justify-between gap-1 overflow-hidden">
            {[45, 62, 85, 30, 95, 78, 42, 60, 90, 82, 35, 70, 88, 55, 65, 40, 92, 50, 75, 48].map((h, i) => (
              <div
                key={i}
                className={`w-full rounded-t-xs transition-all duration-300 ${
                  isVerified
                    ? 'bg-[#a0f399]'
                    : h > 70
                    ? 'bg-[#d32f2f]'
                    : 'bg-[#ffb3ac]'
                } ${isPlayingAudio ? 'animate-pulse' : ''}`}
                style={{
                  height: isPlayingAudio ? `${Math.max(15, (h * 1.2) % 100)}%` : `${h}%`
                }}
              />
            ))}
          </div>

          <div className="flex items-center justify-between pt-1">
            <button
              onClick={handleSimulateAudio}
              className="text-[12px] font-bold text-[#1b6d24] flex items-center gap-1 hover:underline cursor-pointer"
            >
              <span className="material-symbols-outlined text-[16px]">
                {isPlayingAudio ? 'volume_up' : 'play_circle'}
              </span>
              <span>{isPlayingAudio ? 'Auditing Spectrum...' : 'Test Audio Resonance'}</span>
            </button>

            <button
              onClick={handleCopyTelemetry}
              className="text-[12px] text-[#5b403d] hover:text-[#1c1b1b] flex items-center gap-1 cursor-pointer font-medium"
            >
              <span className="material-symbols-outlined text-[15px]">
                {copiedPcap ? 'check' : 'content_copy'}
              </span>
              <span>{copiedPcap ? 'Copied PCAP' : 'Copy Telemetry'}</span>
            </button>
          </div>
        </div>

        {/* Actions */}
        <div className="pt-1 flex flex-col gap-2">
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-[#af101a] text-white text-[14px] font-bold hover:bg-[#8f0912] active:scale-[0.99] transition-all cursor-pointer shadow-xs"
          >
            Dismiss Forensic Record
          </button>
        </div>
      </div>
    </div>
  );
};
