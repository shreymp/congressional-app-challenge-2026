import React, { useState } from 'react';

interface ReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  phoneNumber: string;
  callerLabel?: string;
  onSubmitted: (phone: string) => void;
}

export const ReportModal: React.FC<ReportModalProps> = ({
  isOpen,
  onClose,
  phoneNumber,
  callerLabel,
  onSubmitted
}) => {
  const [reportType, setReportType] = useState('spoofing');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitted(true);
      setTimeout(() => {
        onSubmitted(phoneNumber);
        setSubmitted(false);
        onClose();
      }, 1200);
    }, 800);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 bg-[#313030]/60 backdrop-blur-sm flex flex-col justify-end sm:justify-center p-3 sm:p-4 transition-opacity animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-2xl p-4 shadow-2xl flex flex-col gap-3 max-w-md mx-auto w-full border border-[#eae7e7]"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-1 border-b border-[#f0eded]">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[#af101a] text-[24px]">
              flag
            </span>
            <div>
              <h2 className="text-[17px] font-bold text-[#1c1b1b]">
                FCC & Carrier Fraud Dispatch
              </h2>
              <p className="text-[12px] text-[#5b403d]">{phoneNumber}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[#f0eded] flex items-center justify-center text-[#5b403d] hover:text-[#1c1b1b] cursor-pointer"
          >
            <span className="material-symbols-outlined text-[18px]">close</span>
          </button>
        </div>

        {submitted ? (
          <div className="py-6 flex flex-col items-center justify-center gap-2 text-center">
            <div className="w-12 h-12 rounded-full bg-[#a0f399] text-[#217128] flex items-center justify-center">
              <span className="material-symbols-outlined text-[28px]">check_circle</span>
            </div>
            <h3 className="text-[16px] font-bold text-[#1c1b1b]">
              Report Logged Successfully
            </h3>
            <p className="text-[13px] text-[#5b403d] max-w-xs">
              Dispatched to FCC Consumer Complaint Center & carrier STIR/SHAKEN blacklist registry.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="flex flex-col gap-3">
            <div className="bg-[#f6f3f2] p-3 rounded-xl flex flex-col gap-1 border border-[#e5e2e1]">
              <span className="text-[12px] font-bold text-[#1c1b1b]">
                Incident Target: {phoneNumber}
              </span>
              <span className="text-[12px] text-[#5b403d]">
                Classification: {callerLabel || 'Unverified Robocall'}
              </span>
            </div>

            <div className="flex flex-col gap-1.5">
              <label className="text-[12px] font-bold text-[#1c1b1b]">
                Violation Category
              </label>
              <div className="grid grid-cols-2 gap-1.5">
                {[
                  { id: 'spoofing', label: 'Caller ID Spoofing' },
                  { id: 'impersonation', label: 'Gov/Bank Impersonation' },
                  { id: 'robocall', label: 'Automated Robocall' },
                  { id: 'extortion', label: 'Extortion / Threat' }
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setReportType(item.id)}
                    className={`p-2 rounded-lg text-left text-[12px] font-medium border transition-colors cursor-pointer ${
                      reportType === item.id
                        ? 'border-[#af101a] bg-[#ffdad6] text-[#410003] font-bold'
                        : 'border-[#eae7e7] bg-white text-[#5b403d] hover:bg-[#f6f3f2]'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <label className="text-[12px] font-bold text-[#1c1b1b]">
                Additional Incident Notes (Optional)
              </label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="E.g., Claimed to represent Medicare Part D, robotic voice..."
                rows={2}
                className="w-full text-[13px] p-2.5 rounded-lg border border-[#e5e2e1] bg-white text-[#1c1b1b] focus:outline-none focus:border-[#af101a]"
              />
            </div>

            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-2 rounded-xl bg-[#f0eded] text-[#5b403d] font-bold text-[13px] hover:bg-[#e5e2e1] cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="flex-1 py-2 rounded-xl bg-[#af101a] text-white font-bold text-[13px] hover:bg-[#8f0912] active:scale-[0.98] transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                {isSubmitting ? (
                  <>
                    <span className="material-symbols-outlined text-[16px] animate-spin">sync</span>
                    <span>Broadcasting...</span>
                  </>
                ) : (
                  <>
                    <span className="material-symbols-outlined text-[16px]">send</span>
                    <span>Submit to FCC</span>
                  </>
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
