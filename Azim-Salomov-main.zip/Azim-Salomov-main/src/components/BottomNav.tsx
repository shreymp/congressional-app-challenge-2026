import React from 'react';
import { TabType } from '../types';

interface BottomNavProps {
  activeTab: TabType;
  onChangeTab: (tab: TabType) => void;
  unreadCount?: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onChangeTab,
  unreadCount = 3
}) => {
  const tabs = [
    {
      id: 'live-alert' as TabType,
      label: 'Live Alert',
      icon: 'shield_with_heart',
      badge: undefined
    },
    {
      id: 'avoided-logs' as TabType,
      label: 'Logs',
      icon: 'verified',
      badge: undefined
    },
    {
      id: 'sms-shield' as TabType,
      label: 'SMS Shield',
      icon: 'mark_chat_unread',
      badge: unreadCount > 0 ? unreadCount : undefined
    },
    {
      id: 'family-key-settings' as TabType,
      label: 'Family Key',
      icon: 'vpn_key',
      badge: undefined
    }
  ];

  return (
    <nav className="fixed bottom-0 w-full z-40 pb-safe bg-[#fcf9f8]/92 backdrop-blur-xl shadow-[0_-1px_8px_rgba(0,0,0,0.04)] border-t border-[#f0eded]">
      <div className="max-w-md mx-auto h-16 flex items-center justify-around px-2">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onChangeTab(tab.id)}
              aria-current={isActive ? 'page' : undefined}
              className={`flex flex-col items-center justify-center gap-0.5 min-w-[64px] min-h-[48px] rounded-xl transition-all duration-150 cursor-pointer relative ${
                isActive
                  ? 'text-[#af101a] font-bold'
                  : 'text-[#5b403d] hover:text-[#1c1b1b]'
              }`}
            >
              <div className="relative flex items-center justify-center">
                <span
                  className={`material-symbols-outlined text-[24px] transition-transform ${
                    isActive ? 'scale-110' : ''
                  }`}
                  style={{
                    fontVariationSettings: isActive
                      ? "'FILL' 1, 'wght' 600"
                      : "'FILL' 0, 'wght' 400"
                  }}
                >
                  {tab.icon}
                </span>

                {tab.badge && (
                  <span className="absolute -top-1 -right-2.5 bg-[#af101a] text-white text-[10px] font-bold px-1.5 py-0.2 rounded-full min-w-[16px] text-center leading-tight shadow-xs">
                    {tab.badge}
                  </span>
                )}
              </div>

              <span
                className={`text-[12px] tracking-tight ${
                  isActive ? 'font-bold' : 'font-medium'
                }`}
              >
                {tab.label}
              </span>

              {isActive && (
                <div className="w-1.5 h-1.5 rounded-full bg-[#af101a] -mt-0.5" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
