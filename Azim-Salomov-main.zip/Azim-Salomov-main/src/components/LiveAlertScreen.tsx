import React, { useState, useEffect } from 'react';
import { CallLogItem } from '../types';

interface LiveAlertScreenProps {
  onAddBlockedCall: (log: CallLogItem) => void;
  isGuardActive: boolean;
}

export const LiveAlertScreen: React.FC<LiveAlertScreenProps> = ({
  onAddBlockedCall,
  isGuardActive
}) => {
  const [activeSimulation, setActiveSimulation] = useState<'scam_bank' | 'scam_medicare' | 'scam_clone' | 'verified_mom' | null>(null);
  const [simulationStep, setSimulationStep] = useState<'ringing' | 'analyzing' | 'intercepted' | 'screening' | 'answered'>('ringing');
  const [botTranscript, setBotTranscript] = useState<string[]>([]);
  const [audioWaveProgress, setAudioWaveProgress] = useState(0);

  // Audio wave animation during active call
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (activeSimulation && (simulationStep === 'ringing' || simulationStep === 'analyzing' || simulationStep === 'screening')) {
      interval = setInterval(() => {
        setAudioWaveProgress((prev) => (prev + 1) % 100);
      }, 100);
    }
    return () => clearInterval(interval);
  }, [activeSimulation, simulationStep]);

  const triggerSimulation = (type: 'scam_bank' | 'scam_medicare' | 'scam_clone' | 'verified_mom') => {
    setActiveSimulation(type);
    setSimulationStep('ringing');
    setBotTranscript([]);

    // Simulate real-time acoustic analysis
    setTimeout(() => {
      setSimulationStep('analyzing');
    }, 1000);
  };

  const handleAutoDisconnect = () => {
    setSimulationStep('intercepted');
    
    // Create new log item and add to protection log
    if (activeSimulation === 'scam_bank') {
      onAddBlockedCall({
        id: `sim-${Date.now()}`,
        type: 'scam',
        categoryTag: 'IMPERSONATION',
        statusBadge: 'Safe',
        statusType: 'safe',
        timestamp: 'Just now',
        phoneNumber: '+1 (512) 809-3341',
        callerLabel: 'Bank Fraud Alert Impersonation',
        carrierOrLocation: 'Austin, TX Spoof',
        summaryReason: 'Bank Fraud Alert Impersonation',
        defenseAction: 'Auto-disconnected via Live Shield',
        defenseIcon: 'power_settings_new',
        forensics: {
          callId: `#SHLD-${Math.floor(10000 + Math.random() * 90000)}`,
          clearedStatus: 'CLEARED ZERO EXPOSURE',
          originCarrier: 'Peerless Spoof Gateway (VoIP)',
          sipCode: 'SIP 488 Terminated',
          stirShakenLevel: 'C',
          audioWaveformVariance: '96.8% Synthetic match',
          syntheticMatchPercent: 96.8,
          acousticSignature: 'Real-time spectral analysis intercepted automated financial phishing bot.',
          networkHops: 5,
          callerLocation: 'Austin, TX Spoofed',
          timestamp: 'Just now'
        }
      });
    } else if (activeSimulation === 'scam_clone') {
      onAddBlockedCall({
        id: `sim-${Date.now()}`,
        type: 'scam',
        categoryTag: 'EXTORTION',
        statusBadge: 'Defended',
        statusType: 'defended',
        timestamp: 'Just now',
        phoneNumber: '+1 (312) 555-0199',
        callerLabel: 'AI Voice Clone Emergency Scam',
        carrierOrLocation: 'VoIP Deepfake Injection',
        summaryReason: 'AI Voice Clone Emergency Scam',
        defenseAction: 'Voiceprint Mismatch / Key Failed',
        defenseIcon: 'shield',
        forensics: {
          callId: `#SHLD-${Math.floor(10000 + Math.random() * 90000)}`,
          clearedStatus: 'VOICEPRINT FORGERY BLOCKED',
          originCarrier: 'Offshore SIP Trunk',
          sipCode: 'SIP 603 Declined',
          stirShakenLevel: 'C',
          audioWaveformVariance: '99.4% ElevenLabs Synthetic Model',
          syntheticMatchPercent: 99.4,
          acousticSignature: 'Deepfake voice synthesis mimicking family member. Failed active cryptographic Family Key verification.',
          networkHops: 7,
          callerLocation: 'Offshore Relay Proxy',
          timestamp: 'Just now'
        }
      });
    } else if (activeSimulation === 'scam_medicare') {
      onAddBlockedCall({
        id: `sim-${Date.now()}`,
        type: 'scam',
        categoryTag: 'PHISHING',
        statusBadge: 'Safe',
        statusType: 'safe',
        timestamp: 'Just now',
        phoneNumber: '+1 (888) 234-9012',
        callerLabel: 'Medicare Benefits Robocall',
        carrierOrLocation: 'Toll-Free Spoof',
        summaryReason: 'Medicare Benefits Robocall',
        defenseAction: 'Auto-disconnected via Live Shield',
        defenseIcon: 'power_settings_new',
        forensics: {
          callId: `#SHLD-${Math.floor(10000 + Math.random() * 90000)}`,
          clearedStatus: 'INTERCEPTED & CLEARED',
          originCarrier: 'Twilio Virtual Trunk',
          sipCode: 'SIP 486 Busy',
          stirShakenLevel: 'C',
          audioWaveformVariance: '98.1% Synthetic Robocall',
          syntheticMatchPercent: 98.1,
          acousticSignature: 'Toll-free spoofing cluster flagged on federal blacklist.',
          networkHops: 4,
          callerLocation: 'VoIP Pool',
          timestamp: 'Just now'
        }
      });
    }

    setTimeout(() => {
      setActiveSimulation(null);
    }, 2200);
  };

  const handleDeployScreeningBot = () => {
    setSimulationStep('screening');
    setBotTranscript([
      'CallShield Sentinel: "You have reached an FCC-monitored secure line."',
      'CallShield Sentinel: "State your caller certification and verified identity."',
      'Scammer: "...uh, hello? This is federal officer regarding your..."',
      'CallShield Sentinel: "Biometric analysis: SYNTHETIC VOICE DETECTED. Call aborted."'
    ]);

    setTimeout(() => {
      handleAutoDisconnect();
    }, 3500);
  };

  const isVerifiedCall = activeSimulation === 'verified_mom';

  return (
    <div className="flex flex-col w-full gap-4">
      {/* Live Alert Banner */}
      <div className="flex items-center justify-between pt-1">
        <div className="flex items-center gap-1.5">
          <span className="material-symbols-outlined text-[#af101a] text-[26px]">
            shield_with_heart
          </span>
          <h1 className="text-[26px] font-bold text-[#1c1b1b] tracking-tight">
            Live Interceptor
          </h1>
        </div>

        <div className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-[12px] font-bold ${
          isGuardActive ? 'bg-[#a0f399] text-[#217128]' : 'bg-[#ffdad6] text-[#93000a]'
        }`}>
          <span className="inline-block w-2 h-2 rounded-full bg-current animate-ping" />
          <span>{isGuardActive ? 'SURVEILLANCE ENGAGED' : 'GUARD PAUSED'}</span>
        </div>
      </div>

      {/* Real-time Status Card */}
      <div className="bg-white rounded-xl p-4 shadow-xs border border-[#eae7e7] flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-full bg-[#1b6d24]/10 text-[#1b6d24] flex items-center justify-center">
              <span className="material-symbols-outlined text-[24px]">radar</span>
            </div>
            <div>
              <h2 className="text-[16px] font-bold text-[#1c1b1b]">
                Real-Time Telephony Shield
              </h2>
              <p className="text-[12px] text-[#5b403d]">
                Zero-exposure carrier level filtering active
              </p>
            </div>
          </div>
          <span className="text-[12px] font-mono font-bold text-[#1b6d24] bg-[#a0f399]/40 px-2 py-0.5 rounded">
            LATENCY: 180ms
          </span>
        </div>

        {/* Security telemetry metrics */}
        <div className="grid grid-cols-3 gap-2 pt-1 border-t border-[#f0eded]">
          <div className="flex flex-col text-center p-2 bg-[#f6f3f2] rounded-lg">
            <span className="text-[11px] text-[#5b403d] font-bold">ATTACK BLOCK</span>
            <span className="text-[16px] font-bold text-[#1c1b1b]">99.8%</span>
          </div>
          <div className="flex flex-col text-center p-2 bg-[#f6f3f2] rounded-lg">
            <span className="text-[11px] text-[#5b403d] font-bold">SHAKEN CERT</span>
            <span className="text-[16px] font-bold text-[#1b6d24]">LEVEL A</span>
          </div>
          <div className="flex flex-col text-center p-2 bg-[#f6f3f2] rounded-lg">
            <span className="text-[11px] text-[#5b403d] font-bold">CLONE DEFENSE</span>
            <span className="text-[16px] font-bold text-[#af101a]">ACTIVE</span>
          </div>
        </div>
      </div>

      {/* Interactive Simulation Sandbox */}
      <div className="bg-white rounded-xl p-4 shadow-xs border border-[#eae7e7] flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <span className="text-[13px] font-bold uppercase tracking-wider text-[#5b403d] flex items-center gap-1.5">
            <span className="material-symbols-outlined text-[16px] text-[#af101a]">play_circle</span>
            Simulate Live Incoming Threats
          </span>
          <span className="text-[11px] text-[#5b403d]">Touch to trigger</span>
        </div>

        <p className="text-[13px] text-[#5b403d] leading-relaxed">
          Test CallShield's real-time synthetic voice biometric detection, carrier STIR/SHAKEN verification, and Family Key validation against live simulated callers.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
          <button
            onClick={() => triggerSimulation('scam_bank')}
            className="p-3 rounded-xl border border-[#ffdad6] bg-[#fff2f0] hover:bg-[#ffdad6]/60 text-left flex items-start gap-2.5 transition-all cursor-pointer"
          >
            <div className="w-8 h-8 rounded-full bg-[#af101a] text-white flex items-center justify-center shrink-0 mt-0.5">
              <span className="material-symbols-outlined text-[18px]">account_balance</span>
            </div>
            <div className="flex flex-col min-w-0">
              <span className="text-[13px] font-bold text-[#410003]">
                Bank Fraud Impersonator
              </span>
              <span className="text-[11px] text-[#930010]">
                +1 (512) 809-3341 · Spoofed Caller ID
              </span>
            </div>
          </button>

          <button
            onClick={() => triggerSimulation('scam_clone')}
            className="p-3 rounded-xl border border-[#ffdad6] bg-[#fff2f0] hover:bg-[#ffdad6]/60 text-left flex items-start gap-2.5 transition-all cursor-pointer"
          >
            <div className="w-8 h-8 rounded-full bg-[#af101a] text-white flex items-center justify-center shrink-0 mt-0.5">
              <span className="material-symbols-outlined text-[18px]">record_voice_over</span>
            </div>
            <div className="flex flex-col min-w-0">
              <span className="text-[13px] font-bold text-[#410003]">
                AI Voice Clone / Deepfake
              </span>
              <span className="text-[11px] text-[#930010]">
                Synthetic Voice Mimic · Fake Distress
              </span>
            </div>
          </button>

          <button
            onClick={() => triggerSimulation('scam_medicare')}
            className="p-3 rounded-xl border border-[#eae7e7] bg-[#f6f3f2] hover:bg-[#eae7e7] text-left flex items-start gap-2.5 transition-all cursor-pointer"
          >
            <div className="w-8 h-8 rounded-full bg-[#5b403d] text-white flex items-center justify-center shrink-0 mt-0.5">
              <span className="material-symbols-outlined text-[18px]">smart_toy</span>
            </div>
            <div className="flex flex-col min-w-0">
              <span className="text-[13px] font-bold text-[#1c1b1b]">
                Medicare Benefits Robocall
              </span>
              <span className="text-[11px] text-[#5b403d]">
                +1 (888) 234-9012 · Toll-Free Jitter
              </span>
            </div>
          </button>

          <button
            onClick={() => triggerSimulation('verified_mom')}
            className="p-3 rounded-xl border border-[#a0f399] bg-[#a0f399]/20 hover:bg-[#a0f399]/40 text-left flex items-start gap-2.5 transition-all cursor-pointer"
          >
            <div className="w-8 h-8 rounded-full bg-[#1b6d24] text-white flex items-center justify-center shrink-0 mt-0.5">
              <span className="material-symbols-outlined text-[18px]">vpn_key</span>
            </div>
            <div className="flex flex-col min-w-0">
              <span className="text-[13px] font-bold text-[#005312]">
                Mom (Key #ORCHID-772)
              </span>
              <span className="text-[11px] text-[#217128]">
                Cryptographically Signed Device
              </span>
            </div>
          </button>
        </div>
      </div>

      {/* Active Call Simulator Overlay Modal */}
      {activeSimulation && (
        <div className="fixed inset-0 z-50 bg-[#1c1b1b]/80 backdrop-blur-md flex flex-col justify-between p-4 sm:p-6 animate-in fade-in duration-200">
          {/* Top Status */}
          <div className="max-w-md mx-auto w-full flex items-center justify-between text-white/80 pt-4">
            <div className="flex items-center gap-2">
              <span className="inline-block w-2.5 h-2.5 rounded-full bg-[#a0f399] animate-ping" />
              <span className="text-[12px] font-mono tracking-wider uppercase font-bold">
                CALLSHIELD LIVE GUARD INTERCEPT
              </span>
            </div>
            <span className="text-[12px] font-mono text-white/60">
              00:0{Math.floor(audioWaveProgress / 20) + 1}
            </span>
          </div>

          {/* Caller Identity Card */}
          <div className="max-w-md mx-auto w-full flex flex-col items-center text-center gap-2">
            <div
              className={`w-24 h-24 rounded-full flex items-center justify-center shadow-xl ${
                isVerifiedCall
                  ? 'bg-[#1b6d24] text-white animate-pulse'
                  : 'bg-[#af101a] text-white animate-bounce'
              }`}
            >
              <span className="material-symbols-outlined text-[48px]">
                {isVerifiedCall ? 'verified_user' : 'warning'}
              </span>
            </div>

            <div className="flex flex-col gap-0.5">
              <h3 className="text-[24px] font-bold text-white tracking-tight">
                {isVerifiedCall
                  ? 'Mom (Personal Mobile)'
                  : activeSimulation === 'scam_bank'
                  ? 'Bank Fraud Alert Impersonation'
                  : activeSimulation === 'scam_clone'
                  ? 'UNKNOWN CALLER (VOICE CLONE)'
                  : 'Medicare Benefits Robocall'}
              </h3>
              <p className="text-[16px] text-white/80 font-mono">
                {isVerifiedCall
                  ? '+1 (415) 555-0199'
                  : activeSimulation === 'scam_bank'
                  ? '+1 (512) 809-3341 (Austin, TX Spoofed)'
                  : activeSimulation === 'scam_clone'
                  ? '+1 (312) 555-0199 (Caller ID Forgery)'
                  : '+1 (888) 234-9012 (Toll-Free Relay)'}
              </p>
            </div>

            {/* Live Threat Gauge Box */}
            <div className="w-full bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-3.5 mt-3 flex flex-col gap-2 text-left">
              <div className="flex items-center justify-between">
                <span className="text-[12px] uppercase font-bold tracking-wider text-white/70 flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[15px] text-[#a0f399]">graphic_eq</span>
                  Acoustic Spectrum & Telemetry
                </span>
                <span
                  className={`text-[11px] font-bold px-2 py-0.5 rounded ${
                    isVerifiedCall
                      ? 'bg-[#a0f399] text-[#005312]'
                      : 'bg-[#ffdad6] text-[#93000a]'
                  }`}
                >
                  {isVerifiedCall ? 'VALIDATED SAFE' : 'CRITICAL THREAT'}
                </span>
              </div>

              {/* Dynamic waveform visualization */}
              <div className="h-8 flex items-center gap-1 justify-between px-1">
                {[30, 60, 95, 40, 80, 50, 100, 75, 45, 90, 65, 85, 35, 70, 95, 40].map((h, i) => (
                  <div
                    key={i}
                    className={`w-1.5 rounded-full transition-all duration-150 ${
                      isVerifiedCall ? 'bg-[#a0f399]' : 'bg-[#ffdad6]'
                    }`}
                    style={{
                      height: `${Math.max(15, (h + audioWaveProgress * 3) % 100)}%`
                    }}
                  />
                ))}
              </div>

              <div className="text-[12px] text-white/90 space-y-1 font-mono">
                {isVerifiedCall ? (
                  <>
                    <div className="text-[#a0f399] flex items-center gap-1">
                      <span className="material-symbols-outlined text-[14px]">key</span>
                      <span>Family Passphrase: #ORCHID-772 Handshake Confirmed</span>
                    </div>
                    <div className="text-white/70">STIR/SHAKEN Attestation: Level A (Cryptographically Signed)</div>
                  </>
                ) : (
                  <>
                    <div className="text-[#ffdad6] flex items-center gap-1 font-bold">
                      <span className="material-symbols-outlined text-[14px]">dangerous</span>
                      <span>
                        {activeSimulation === 'scam_clone'
                          ? 'Deepfake Jitter: 99.4% AI Voice Synthesis Match'
                          : 'SIP Gateway: Unverified VoIP spoofing cluster'}
                      </span>
                    </div>
                    <div className="text-white/70">STIR/SHAKEN Attestation: Level C (Fails Carrier Origin)</div>
                  </>
                )}
              </div>

              {/* Live Screening Bot Transcript if active */}
              {simulationStep === 'screening' && botTranscript.length > 0 && (
                <div className="bg-black/40 rounded-lg p-2 text-[11px] font-mono text-white/90 space-y-1 border border-white/10 max-h-24 overflow-y-auto">
                  {botTranscript.map((line, idx) => (
                    <div key={idx} className={line.startsWith('CallShield') ? 'text-[#a0f399]' : 'text-[#ffdad6]'}>
                      {line}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="max-w-md mx-auto w-full flex flex-col gap-2.5 pb-4">
            {simulationStep === 'intercepted' ? (
              <div className="bg-[#a0f399] text-[#005312] p-4 rounded-2xl text-center font-bold flex items-center justify-center gap-2">
                <span className="material-symbols-outlined text-[24px]">check_circle</span>
                <span>Call Intercepted & Disconnected with Zero Exposure!</span>
              </div>
            ) : isVerifiedCall ? (
              <div className="flex gap-2">
                <button
                  onClick={() => setActiveSimulation(null)}
                  className="flex-1 py-4 rounded-2xl bg-white/20 text-white font-bold text-[16px] hover:bg-white/30 cursor-pointer"
                >
                  Decline
                </button>
                <button
                  onClick={() => {
                    setSimulationStep('answered');
                    setTimeout(() => setActiveSimulation(null), 1500);
                  }}
                  className="flex-2 py-4 rounded-2xl bg-[#1b6d24] text-white font-bold text-[16px] flex items-center justify-center gap-2 shadow-lg hover:bg-[#165a1e] cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[22px]">call</span>
                  <span>Answer Secure Call</span>
                </button>
              </div>
            ) : (
              <div className="flex flex-col gap-2">
                <button
                  onClick={handleAutoDisconnect}
                  className="w-full py-3.5 rounded-2xl bg-[#af101a] text-white font-bold text-[16px] flex items-center justify-center gap-2 shadow-xl hover:bg-[#8f0912] active:scale-[0.98] transition-all cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[22px]">call_end</span>
                  <span>Auto-Disconnect via Live Shield</span>
                </button>

                <div className="flex gap-2">
                  <button
                    onClick={handleDeployScreeningBot}
                    className="flex-1 py-3 rounded-xl bg-white/20 hover:bg-white/30 text-white font-bold text-[13px] flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <span className="material-symbols-outlined text-[18px]">smart_toy</span>
                    <span>Screen with AI Counter-Bot</span>
                  </button>

                  <button
                    onClick={() => {
                      handleAutoDisconnect();
                    }}
                    className="flex-1 py-3 rounded-xl bg-[#d32f2f]/40 hover:bg-[#d32f2f]/60 text-white font-bold text-[13px] flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <span className="material-symbols-outlined text-[18px]">flag</span>
                    <span>Block & Report FCC</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
